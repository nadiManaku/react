import glamorous from "glamorous";

const Title = glamorous.h1({
    fontSize: '20',
    color: '#fff',
    textAlign: 'center',
    paddingTop: '30px'
})

export default Title;