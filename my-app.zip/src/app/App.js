import React, { Component } from 'react';

import { Router, Route, browserHistory } from 'react-router';
//import logo from './logo.svg';
import './App.css';
import StarComponent from './starComponent/starComponent';
import HomeComponent from './Home/homeComponent'
import UsersComponent from './users/usersComponent'

class App extends Component {

  render() {
    return (
      <React.Fragment>
        <Router history={browserHistory}>
          <Route exact path="/home" component={HomeComponent} />
          <Route exact path='/star' component={StarComponent} />
          <Route exact path='/' component={UsersComponent} />
        </Router>
      </React.Fragment>
    );
  }
}

export default App;
